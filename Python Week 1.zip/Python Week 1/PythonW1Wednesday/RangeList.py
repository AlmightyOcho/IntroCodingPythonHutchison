name = "Ryan"

for x in range(5, 10):
    print("Hello there, %s" % name)
