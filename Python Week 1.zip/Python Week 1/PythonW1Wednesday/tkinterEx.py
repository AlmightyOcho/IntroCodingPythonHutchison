import tkinter as tk

root = tk.Tk()

logo = tk.PhotoImage(file="cat.jpg")

w1 = tk.Label(root, image=logo).pack(side="right")

info = """At present, this is a picture of a cat,
        this is a picture of a cat,
        this is a picture of a cat,
        this is a picture of a cat"""

w2 = tk.Label(root, justify=tk.LEFT, padx = 10, text = info).pack(side="left")

root.mainloop()
