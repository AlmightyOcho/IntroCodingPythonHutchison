import turtle

BananaBob = turtle.Turtle()

BananaBob.penup()

BananaBob.goto(-100,0)

BananaBob.pendown()

BananaBob.lt(90)
BananaBob.fd(100)       #position -100,100

BananaBob.bk(60)         

BananaBob.rt(90)
BananaBob.fd(40)        #position -60, 70

BananaBob.rt(90)
BananaBob.fd(40)        #position -100, 70

BananaBob.rt(90)
BananaBob.fd(40)        # LETTER B

BananaBob.penup()
BananaBob.bk(70)

BananaBob.pendown()

BananaBob.rt(90)
BananaBob.fd(40)        

BananaBob.rt(90)
BananaBob.fd(40)        

BananaBob.rt(90)
BananaBob.fd(40) 

BananaBob.rt(90)
BananaBob.fd(40)

BananaBob.penup()



BananaBob.goto(100,0)

BananaBob.pendown()

BananaBob.lt(90)
BananaBob.fd(100)       #position -100,100

BananaBob.bk(60)         

BananaBob.rt(90)
BananaBob.fd(40)        #position -60, 70

BananaBob.rt(90)
BananaBob.fd(40)        #position -100, 70

BananaBob.rt(90)
BananaBob.fd(40) 

