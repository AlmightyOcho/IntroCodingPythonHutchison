import turtle	# import

s = turtle.getscreen() # open turtle screen
t = turtle.Turtle() #  initialize the variable t, which you’ll then use throughout the program to refer to the turtle

# Up means that no line will be drawn when it moves.
# Down means that a line will be drawn when it moves.

t.right(90)	# t.rt() instead of t.right()
t.forward(100) # t.fd() instead of t.forward()
t.left(90) # t.lt() instead of t.left()
t.backward(100) # t.bk() instead of t.backward()


t.goto(100,100) # a coordinate

t.home()	# reset turtle to original position

#polygon
t.fd(100)
t.rt(90)
t.fd(100)
t.rt(90)
t.fd(100)
t.rt(90)
t.fd(100)

# How would we draw a rectangle?

# How would we draw a star?

#circle
t.circle(60)

#dot
t.dot(20)

#bg-color
turtle.bgcolor("blue")

#Screen Title
turtle.title("My Turtle Program")

#Turtle size
t.shapesize(1,5,10)
t.shapesize(10,5,1)
t.shapesize(1,10,5)
t.shapesize(10,1,5)

#pen size
t.pensize(5)
t.forward(100)