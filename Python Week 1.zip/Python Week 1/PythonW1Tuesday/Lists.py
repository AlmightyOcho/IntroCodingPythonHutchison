#Lists

emptyList = [ ]  

list1 = ['one, two, three, four, five']

numlist = [1, 3, 5, 7, 9]

mixlist = ['yellow', 'red', 'blue', 'green', 'black']

#An empty list is created using just square brackets:
list = []

list = ["1", "hello", 2, "world"]
len(list)
>>4

list.insert(0, "Files")

list = ["Movies", "Music", "Pictures"]
 
list.append(x) #will add an element to the end of the list
list.append("Files")

print list
['Movies', 'Music', 'Pictures', 'Files’]

list.insert(x, y) 	#will add element y on the place before x

list = ["Movies", "Music", "Pictures"] 

list.insert(2,"Documents")

print list
['Movies', 'Music', 'Documents', 'Pictures', 'Files']

#You can insert a value anywhere in the list

list = ["Movies", "Music", "Pictures"] 
list.insert(3, "Apps”)