import wptools

page = wptools.page('Theodore Roosevelt')

page.get_parse()

print(page.data['infobox']['birth_place'])