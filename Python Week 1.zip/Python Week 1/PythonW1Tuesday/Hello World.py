print("Hello World " * 3)

print("Good morning, Hutchison!")