# Swap two variables

a = "hello"
b = "bye" 

print(a + b)

a, b = b, a

print(a + b)
