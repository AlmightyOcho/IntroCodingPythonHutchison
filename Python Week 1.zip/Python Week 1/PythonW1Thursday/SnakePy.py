import turtle as tu
import time
import random

delay = 0.1

# Score
score = 0
high_score = 0

# Set up the screen
win = tu.Screen()
win.title("Ryan's Snake Game")
win.bgcolor("black")
win.setup(width=600, height=600)
win.tracer(0)

# Create the snake's head
snakey = tu.Turtle()
snakey.speed(0)
snakey.shape("circle")
snakey.color("blue")
snakey.penup()
snakey.goto(0, 100)
snakey.direction = "stop"

# Snakeys food
food = tu.Turtle()
food.speed(0)
food.shape("square")
food.color("red")
food.penup()
food.goto(0, 100)

segments = []

# Pen
pen = tu.Turtle()
pen.speed(0)
pen.shape("square")
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Score: 0 High Score: 0", align="center", font=("Courier", 24, "normal"))

# Functions to move Snakey
def go_up():
    if snakey.direction != "down":   # if direction is != down
        snakey.direction = "up"
def go_down():
    if snakey.direction != "up":   # if direction is != down
        snakey.direction = "down"
def go_right():
    if snakey.direction != "left":   # if direction is != down
        snakey.direction = "right"
def go_left():
    if snakey.direction != "right":   # if direction is != down
        snakey.direction = "left"

def move(): # all functions begin with keyword def
    if snakey.direction == "up":        # check Snakeys direction
        y = snakey.ycor()   # y-cor of Snakey
        snakey.sety(y + 20)
    if snakey.direction == "down":
        y = snakey.ycor()  
        snakey.sety(y - 20)
    if snakey.direction == "right":
        x = snakey.xcor()   # x-cor of Snakey
        snakey.setx(x + 20) 
    if snakey.direction == "left":
        x = snakey.xcor()
        snakey.setx(x - 20)

        
# keyboard bindings
win.listen()
win.onkeypress(go_up, "w")
win.onkeypress(go_down, "s")
win.onkeypress(go_right, "d")
win.onkeypress(go_left, "a")

# Main game loop
while True:
    win.update()

    # Check for a collision with the border
    if snakey.xcor() > 290 or snakey.xcor() < -290 or snakey.ycor() > 290 or snakey.ycor() < -290:
        time.sleep(1)
        snakey.goto(0,0)
        snakey.direction = "stop"

        # Hide the body
        for segment in segments:
            segment.goto(1000, 1000)

        # Clear the segments list
        segments.clear()

        # Reset the score
        score = 0

        # Reset the delay
        delay = 0.1

        pen.clear() #immutable
        pen.write("Score: {} High Score: {}".format(score, high_score), align="center", font=("Courier", 24, "normal"))

    # Check for a collision with the food
    if snakey.distance(food) < 20:
        # Move the food to a random spot
        x = random.randint(-290, 290)
        y = random.randint(-290, 290)
        food.goto(x, y)

        # Add a segment
        new_segment = tu.Turtle()
        new_segment.speed(0)
        new_segment.shape("square")
        new_segment.color("grey")
        new_segment.penup()
        segments.append(new_segment)


        #Shorten the delay
        delay -= 0.001

        #Increase the score
        score += 10

        if score > high_score:
            high_score = score

        pen.clear()
        pen.write("Score: {} High Score: {}".format(score, high_score), align="center", font=("Courier", 24, "normal"))

    # Move the end segments first in reverse order
    for index in range(len(segments)-1, 0, -1):
        x = segments[index-1].xcor()
        y = segments[index-1].ycor()
        segments[index].goto(x,y)

    # Move segment 0 to where the head is
    if len(segments) > 0:
        x = snakey.xcor()
        y = snakey.ycor()
        segments[0].goto(x, y)

    move()

    # Check for head collision with the body segments
    for segment in segments:
        if segment.distance(snakey) < 20:
            time.sleep(1)
            snakey.goto(0,0)
            snakey.direction = "stop"

            #Hide the segments
            for segment in segments:
                segment.goto(1000, 1000)

            # CLear the segments list
            segments.clear()

            # Reset the score
            score = 0

            # Reset the delay
            delay = 0.1

            #Update the score display
            pen.clear()
            pen.write("Score: {} High Score: {}".format(score, high_score), align="center", font=("Courier", 24, "normal"))

    time.sleep(delay)

win.mainloop()
