import turtle
p = turtle.Pen()
p.speed(0)
p.pencolor("red")
for x in range(100):
    p.forward(2*x)
    p.left(91)
