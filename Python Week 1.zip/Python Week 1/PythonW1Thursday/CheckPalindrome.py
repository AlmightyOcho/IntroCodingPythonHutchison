# Palindrome Program

#The data
phrase = "ttattarrattattttattarrattattttattarrattattttattarrattattttattarrattatt"

#The one liner
is_palindrome = phrase.find(phrase[::-1])

#The Result
print(is_palindrome)

# 0 (if it wasn't a palindrome, the result would be -1)
