# Example Rock, Paper, Scissors: The Video Game

# random allows us to deal with random numbers
import random
# time allows us to manipulate time of our system
import time

# Define our characters
rock = 1
paper = 2
scissors = 3

# Names defines the name of the items
# Dictionaries work with key/value pairs
names = {rock: "Rock", paper: "Paper", scissors: "Scissors"}

# Rules keeps track of what overpowers what
rules = {rock: scissors, scissors: paper, paper: rock}

player_score = 0
computer_score = 0

# Defining our 6 methods
def start():
    print("Let's play a game of Rock, Paper, Scissors.")

    # While loop tells us to run the game() method
    while game():
        pass
    # Run the scores() method as well
    scores()

def game():
    player = move()
    
    # This function randint is a part of the random module, and returns a random int between 1 & 3
    computer = random.randint(1, 3)
    result(player, computer)
    return play_again()

def move():
    while True:
        print("")
        # Ask the player what move they're going to make
        player = input("Rock = 1\nPaper = 2\nScissors = 3\nMake a move: ")
        try:
            player = int(player)
            if player in (1,2,3):
                return player
        except ValueError:
            pass
        print("Oops! I didn't understand that. Please enter 1, 2, or 3.")

def result(player, computer):
    print("1...")
    time.sleep(1)
    print("2...")
    time.sleep(1)
    print("3!")
    time.sleep(0.5)
    print("Computer threw {0}!".format(names[computer]))
    global player_score, computer_score
    # This line will check the players move vs. the computers move
    if player == computer:
        print("Tie game.")
    else:
        # Again, the rules were..{rock beats scissors, scissors beats paper, paper beats rock}
        if rules[player] == computer:
            print("Your victory has been assured!")
            player_score += 1
        else:
            print("The computer laughs as you realize you have been defeated...")
            computer_score += 1
            
def play_again():
    answer = input("Do you want to play again? Y/n ")
    if answer  in ("y", "Y", "yes", "Yes", "Of course!"):
        return answer
    else:
        print("Thank you very much for playing our game. See you next time!")
    
def scores():
    global player_score, computer_score
    print("HIGH SCORES")
    print("Player: " + player_score)
    print("Computer: " + computer_score)

# Our program's main method
if __name__ == '__main__':
    start()
