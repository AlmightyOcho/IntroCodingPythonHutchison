import turtle
import time

# Create a screen
screen = turtle.getscreen()

# Set our background color
screen.bgcolor("#b3daff")

# Set the title of our screen
screen.title("Flag of India in Turtle")

# Now we create our Turtle
Bobie = turtle.Turtle()

# We shall set the the cursor/turtle speed.
# Higher value, faster is the turtle.
Bobie.speed(10)
Bobie.penup()

# Decide the shape of our Turtle
Bobie.shape("turtle")

# Flag to height ratio is 2:3
flag_height = 300
flag_width = 450

# Starting points
# Start from the 1st quadrant, half of flag width & half of flag height
start_x = -225
start_y = 150

# For saffron, white and green stripes, each strip width will be flag height / 3 = 100
stripe_height = flag_height / 3
stripe_width = flag_width

# Radius of Ashok Chakra, half of white stripe
chakra_radius = stripe_height / 2

# Function to fill our flag
def draw_fill_rectangle(x, y, height, width, color):
    Bobie.goto(x,y)
    Bobie.pendown()
    Bobie.color(color)
    Bobie.begin_fill()
    Bobie.forward(width)
    Bobie.right(90)
    Bobie.forward(height)
    Bobie.right(90)
    Bobie.forward(width)
    Bobie.right(90)
    Bobie.forward(height)
    Bobie.right(90)
    Bobie.end_fill()
    Bobie.penup()

# this function is used to create our 3 stripes
def draw_stripes():
    x = start_x
    y = start_y
    
    # We need 3 total stripes: 1 saffron, 1 white, 1 green
    draw_fill_rectangle(x, y, stripe_height, stripe_width, "#ff9933")

    # decrease value of y by stripe_height
    y = y - stripe_height

    # create our middle stripe
    draw_fill_rectangle(x, y, stripe_height, stripe_width, "white")
    y = y - stripe_height

    # Finally, our last green stripe
    draw_fill_rectangle(x, y, stripe_height, stripe_width, "#138808")
    y = y - stripe_height

def draw_chakra():
    Bobie.speed(1)
    Bobie.goto(0,0)
    # Navy blue
    color = "#000080"
    Bobie.penup()
    Bobie.color(color)
    Bobie.fillcolor(color)
    Bobie.goto(0,0 - chakra_radius)
    Bobie.pendown()
    Bobie.circle(chakra_radius)
    # 24 spokes of the wheel
    for _ in range(24):
        Bobie.penup()
        Bobie.goto(0,0)
        Bobie.left(15)
        Bobie.pendown()
        Bobie.forward(chakra_radius)
        
# Set to start after 5 seconds.
time.sleep(5)
# Draw 3 stripes
draw_stripes()
# Draw squares to hold stars
draw_chakra()
# Hide the turtle
Bobie.hideturtle()
# Keep holding the screen until closed manually
screen.mainloop()
