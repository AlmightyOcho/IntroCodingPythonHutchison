import turtle

# Create the screen and the turtle
s = turtle.Turtle()
s2 = turtle.Turtle()

p = turtle.Screen()


# This holds the colors we'll use

# colors = ['0', '1', '2', '3', '4']
colors = ['lavender', 'pink', 'blue',
          'green', 'yellow', 'red']


# Sets the background color of our screen 
p.bgcolor('black')

# for loop iterates numbers 0 - 359 using the range funciton
for x in range(360):
    
    # Set our 'pencolor' to the "x % 6" color from colors
    # x % 6 returns the remainder after integer division
    
    s.pencolor(colors[x % 6]), s2.pencolor(colors[x % 6])


    # Set turtle width, remember that variable 'x' is increased after each completion of the for loop
    s.width(x/100 + 1), s2.width(x/100 + 1)

    # Turtle moves forward according to variable 'x'
    s.forward(x), s2.forward(x)

    # Turtle rotates to the left 59 pixels
    s.right(59), s2.left(59)

