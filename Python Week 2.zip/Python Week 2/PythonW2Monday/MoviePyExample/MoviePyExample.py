import moviepy.editor

# First assign file locations

# This line should includes the name of your video file, if otherwise named "Small.mp4"

video =

audio =

# Video to Audio conversion
