Hello Hutchison!
This is a short example of how to convert a video file (.mp4, .avi, & most other extensions supported) using the module MoviePy.

First, you'll want to install the library via the command line:
From Windows, type: 'open CMD'

Next, type: 'pip install moviepy'
Wait a few seconds as the module (moviepy) is installed.

Now, try and open/run the python file (VidToAudio.py) from within IDLE or any other IDE (Integrated Development Environment) of your choice..