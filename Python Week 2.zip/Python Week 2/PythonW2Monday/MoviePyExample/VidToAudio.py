import moviepy.editor

# First assign file locations

# This line should include the name of your video file, if otherwise named "Sample.mp4"
video = moviepy.editor.VideoFileClip("Sample.mp4")

audio = video.audio

# Video to Audio conversion
audio.write_audiofile("sample.mp3")
