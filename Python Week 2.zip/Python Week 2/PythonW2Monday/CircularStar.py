import turtle

s = turtle.Turtle()

s.color('red', 'yellow')
s.begin_fill()

while True:
    s.forward(200)
    s.left(170)
    if abs(s.pos()) < 1:
        break

s.end_fill()
done()
